#!/usr/bin/env python3
"""
LOCKED VAULT — Corporate Secrets Encryption System
The vault protects classified data with a passphrase-derived key.
Only authorized personnel with the correct passphrase can decrypt.
"""
import bcrypt, os, json
from hashlib import sha256
from Crypto.Cipher import AES
from Crypto.Util.Padding import pad

# ═══════════════════════════════════════════════════════════
#  SECURITY POLICY v2.3
#  All vault passphrases MUST follow the corporate standard:
#
#    Format:  [color][animal][two-digit number]
#    Rules:   all lowercase, no separators, no spaces
#
#    Approved colors:
#      red blue green black white yellow purple orange
#      pink brown gray silver gold cyan violet
#
#    Approved animals:
#      cat dog fox wolf bear lion tiger eagle hawk owl
#      deer elk moose snake shark whale horse pony bull crow
#      dove duck frog goat lamb mole moth newt oxen pike
#      puma raven robin seal slug swan toad wasp worm zebra
#      ape bat bee cod cow eel hen jay rat yak
#
#    Number: 00 through 99
#
#    Example: "redcat42", "bluefox17", "goldeagle99"
# ═══════════════════════════════════════════════════════════


def lock_vault(flag, passphrase):
    # Store bcrypt hash for authentication (cost 12)
    pass_hash = bcrypt.hashpw(passphrase.encode(), bcrypt.gensalt(rounds=12))

    # Derive AES-128 key from passphrase
    aes_key = sha256(passphrase.encode()).digest()[:16]

    # Encrypt the classified data
    iv = os.urandom(16)
    ct = AES.new(aes_key, AES.MODE_CBC, iv).encrypt(pad(flag.encode(), 16))

    return {
        "vault_info": "AES-128-CBC encrypted. Key = SHA256(passphrase)[:16]. Crack the hash, crack the vault.",
        "passphrase_hash": pass_hash.decode(),
        "iv": iv.hex(),
        "ciphertext": ct.hex()
    }


if __name__ == "__main__":
    flag = open("flag.txt").read().strip()
    passphrase = input("Enter vault passphrase: ")
    result = lock_vault(flag, passphrase)
    with open("output.txt", "w") as f:
        json.dump(result, f, indent=2)
    print("Vault locked.")
