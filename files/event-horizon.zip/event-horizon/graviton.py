#!/usr/bin/env python3
"""
EVENT HORIZON — The Graviton Cipher
Beyond this point, mathematics collapses.
Three layers guard the singularity. Peel them all — in order.
"""
from Crypto.Util.number import getPrime, bytes_to_long, long_to_bytes, inverse, GCD
from Crypto.Cipher import AES
from Crypto.Util.Padding import pad
from hashlib import sha256
import struct, os, json


# ═══════════════════════════════════════════════════════════
#  MT19937 — Standard Mersenne Twister PRNG
# ═══════════════════════════════════════════════════════════
class MT19937:
    def __init__(self, seed):
        self.mt = [0] * 624
        self.index = 624
        self.mt[0] = seed & 0xFFFFFFFF
        for i in range(1, 624):
            self.mt[i] = (1812433253 * (self.mt[i-1] ^ (self.mt[i-1] >> 30)) + i) & 0xFFFFFFFF

    def twist(self):
        for i in range(624):
            y = (self.mt[i] & 0x80000000) | (self.mt[(i+1) % 624] & 0x7FFFFFFF)
            self.mt[i] = self.mt[(i + 397) % 624] ^ (y >> 1)
            if y & 1:
                self.mt[i] ^= 0x9908B0DF
        self.index = 0

    def extract(self):
        if self.index >= 624:
            self.twist()
        y = self.mt[self.index]
        y ^= (y >> 11)
        y ^= (y << 7) & 0x9D2C5680
        y ^= (y << 15) & 0xEFC60000
        y ^= (y >> 18)
        self.index += 1
        return y & 0xFFFFFFFF


# ═══════════════════════════════════════════════════════════
#  LAYER 1: Gravitational Lensing
#  RSA encryption with a carefully chosen focal length.
# ═══════════════════════════════════════════════════════════
def gravitational_lens(alpha):
    p, q = getPrime(512), getPrime(512)
    N = p * q
    phi = (p - 1) * (q - 1)

    # The focal length — chosen for optimal distortion
    d = int.from_bytes(os.urandom(25), 'big') | 1
    while GCD(d, phi) != 1:
        d = int.from_bytes(os.urandom(25), 'big') | 1
    e = inverse(d, phi)

    c = pow(alpha, e, N)
    return {"N": N, "e": e, "c": c}


# ═══════════════════════════════════════════════════════════
#  LAYER 2: Spaghettification
#  Matter stretches as it falls. Two streams, one source.
# ═══════════════════════════════════════════════════════════
def spaghettify(source, alpha):
    p, q = getPrime(512), getPrime(512)
    N = p * q
    e = 3
    beta = int.from_bytes(os.urandom(32), 'big')

    stream_a = source
    stream_b = (alpha * source + beta) % N

    c_a = pow(stream_a, e, N)
    c_b = pow(stream_b, e, N)
    return {"N": N, "e": e, "c_a": c_a, "c_b": c_b, "beta": beta}


# ═══════════════════════════════════════════════════════════
#  LAYER 3: Hawking Radiation
#  Quantum fluctuations at the horizon emit structured noise.
#  The radiation is masked — you need the source to see through it.
# ═══════════════════════════════════════════════════════════
def hawking_radiation(source):
    seed = struct.unpack('>I', sha256(long_to_bytes(source)).digest()[:4])[0]
    rng = MT19937(seed)

    # Generate 624 observable + 4 hidden outputs
    outputs = [rng.extract() for _ in range(628)]

    # Mask the observable radiation with the entropy source
    source_bytes = long_to_bytes(source)
    masked = []
    for i in range(624):
        mask = struct.unpack('>I',
            sha256(source_bytes + struct.pack('>I', i)).digest()[:4]
        )[0]
        masked.append(outputs[i] ^ mask)

    # The unobservable outputs beyond the horizon form the key
    key = b''.join(struct.pack('>I', outputs[624 + j]) for j in range(4))
    return masked, key


# ═══════════════════════════════════════════════════════════
#  ASSEMBLY — Three layers collapse into the singularity
# ═══════════════════════════════════════════════════════════
if __name__ == "__main__":
    FLAG = open("flag.txt", "rb").read().strip()

    alpha = int.from_bytes(os.urandom(16), 'big')      # 128-bit lens parameter
    source = int.from_bytes(os.urandom(50), 'big')      # ~400-bit entropy source

    layer1 = gravitational_lens(alpha)
    layer2 = spaghettify(source, alpha)
    masked_radiation, aes_key = hawking_radiation(source)

    # IV ties all recovered secrets together
    aes_iv = sha256(long_to_bytes(alpha) + long_to_bytes(source)).digest()[:16]
    ct = AES.new(aes_key, AES.MODE_CBC, aes_iv).encrypt(pad(FLAG, 16))

    output = {
        "layer_1_gravitational_lens": {
            "description": "RSA-encrypted coordinate. The focal length was chosen... carefully.",
            "N": str(layer1["N"]),
            "e": str(layer1["e"]),
            "c": str(layer1["c"]),
        },
        "layer_2_spaghettification": {
            "description": "Two matter streams from the same source, stretched differently.",
            "N": str(layer2["N"]),
            "e": layer2["e"],
            "c_a": str(layer2["c_a"]),
            "c_b": str(layer2["c_b"]),
            "beta": str(layer2["beta"]),
        },
        "layer_3_hawking_radiation": {
            "description": "624 quanta of masked radiation. The pattern hides the key to escape.",
            "masked_outputs": masked_radiation,
        },
        "singularity": {
            "description": "The flag lies beyond. AES-128-CBC. Derive the key and IV from what you recover.",
            "ciphertext": ct.hex(),
        },
    }

    with open("output.txt", "w") as f:
        json.dump(output, f, indent=2)
    print("Output written to output.txt")
