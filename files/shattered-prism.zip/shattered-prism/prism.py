#!/usr/bin/env python3
"""
SHATTERED PRISM — Encryption System
Three facets protect the master key. All three must fall.
"""
from Crypto.Util.number import getPrime, bytes_to_long, long_to_bytes, inverse
from Crypto.Cipher import AES
from Crypto.Util.Padding import pad
from hashlib import sha256
import os, json

FLAG = open("flag.txt", "rb").read().strip()

# ─── Facet A: RSA Broadcast ──────────────────────────────────
# Same secret encrypted under three independent RSA public keys.
def facet_a():
    e = 3
    secret = os.urandom(48)  # 384-bit secret
    m = bytes_to_long(secret)
    pairs = []
    for _ in range(3):
        while True:
            p, q = getPrime(512), getPrime(512)
            n = p * q
            if m < n:
                break
        pairs.append({"n": n, "c": pow(m, e, n)})
    return secret, {"e": e, "pairs": pairs}

# ─── Facet B: Discrete Logarithm ─────────────────────────────
# Standard DLP: given g, p, and h = g^x mod p, find x.
# Prime p was selected from our internal parameter generator.
def facet_b(p, g):
    raw = os.urandom(32)
    x = bytes_to_long(raw) % (p - 1)
    h = pow(g, x, p)
    return x, {"p": p, "g": g, "h": h}

# ─── Facet C: Elliptic Curve DLP ─────────────────────────────
# Given curve y^2 = x^3 + ax + b over GF(p), base point G,
# and P = k*G, find k.
# Curve parameters were derived from an internal seed.
def facet_c(p, a, b, G):
    raw = os.urandom(32)
    k = bytes_to_long(raw) % (p - 1)
    P = ec_scalar_mul(G, k, a, b, p)
    return k, {"p": p, "a": a, "b": b, "G": G, "P": P}

def ec_scalar_mul(G, k, a, b, p):
    """Scalar multiplication using internal mapping."""
    # Implementation uses optimized coordinate system
    # [details omitted — output computed offline]
    pass

# ─── Key Derivation & Encryption ─────────────────────────────
seed_a, out_a = facet_a()          # 48 bytes from Hastad
x_b, out_b    = facet_b(P_B, G_B) # integer from DLP
k_c, out_c    = facet_c(P_C, A_C, B_C, G_C)  # integer from ECDLP

aes_key = sha256(seed_a + long_to_bytes(x_b)).digest()[:16]
aes_iv  = sha256(long_to_bytes(k_c)).digest()[:16]
ct = AES.new(aes_key, AES.MODE_CBC, aes_iv).encrypt(pad(FLAG, 16))

output = {
    "facet_a": out_a,
    "facet_b": out_b,
    "facet_c": out_c,
    "final":   {"ciphertext": ct.hex()}
}
with open("output.txt", "w") as f:
    json.dump(output, f, indent=2)
